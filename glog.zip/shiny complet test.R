library(shiny)

# Définir le chemin vers votre répertoire contenant index.html
html_dir <- file.path(getwd(), "GenomeBrowser_H5N1")
html_file <- file.path(html_dir, "index.html")

# Définir un alias pour le répertoire contenant les ressources
shiny::addResourcePath("genomeBrowser", html_dir)

# Créer une application Shiny avec des onglets
ui <- fluidPage(
  titlePanel("Plateforme Génétique H5N1"),
  
  sidebarLayout(
    sidebarPanel(
      fileInput("fastaFile", "Charger une séquence FASTA", accept = ".fasta"),
      selectInput("savedSequence", "Sélectionner une séquence sauvegardée",
                  choices = list.files("data", pattern = "\\.rds$")),
      actionButton("analyze", "Lancer l'analyse")
    ),
    
    mainPanel(
      tabsetPanel(
        # Onglet pour l'analyse globale
        tabPanel("Analyse globale", 
                 verbatimTextOutput("globalAnalysis")),
        
        # Onglet pour l'analyse locale
        tabPanel("Analyse locale", 
                 verbatimTextOutput("localAnalysis")),
        
        # Onglet pour la phylogénèse (ajoute ton code de phylogénie ici)
        tabPanel("Phylogenèse", 
                 plotOutput("phylogenyPlot")),
        
        # Onglet pour la visualisation du génome
        tabPanel("Visualisation", 
                 tags$iframe(src = "genomeBrowser/index.html", 
                             width = "100%", height = "800px"))
      )
    )
  )
)

# Fonction serveur
server <- function(input, output, session) {
  
  # Charger le fichier FASTA et sauvegarder
  observeEvent(input$fastaFile, {
    sequence <- readDNAStringSet(input$fastaFile$datapath)
    saveRDS(sequence, file = paste0("data/", input$fastaFile$name, ".rds"))
  })
  
  # Charger la séquence sélectionnée pour comparaison
  selectedSequence <- reactive({
    req(input$savedSequence)
    readRDS(paste0("data/", input$savedSequence))
  })
  
  # Exemple de logique pour afficher une analyse globale
  output$globalAnalysis <- renderPrint({
    # Code d'analyse globale (à personnaliser selon ton besoin)
    cat("Affichage de l'analyse globale pour la séquence sélectionnée.")
  })
  
  # Exemple de logique pour afficher une analyse locale
  output$localAnalysis <- renderPrint({
    # Code d'analyse locale (à personnaliser selon ton besoin)
    cat("Affichage de l'analyse locale pour la séquence sélectionnée.")
  })
  
  # Exemple de plot pour la phylogénèse
  output$phylogenyPlot <- renderPlot({
    # Code pour générer un plot phylogénétique (à personnaliser selon ton besoin)
    plot(1:10, 1:10, main = "Phylogénèse")
  })
}

# Lancer l'application Shiny
shinyApp(ui = ui, server = server)
