# Installer et charger le package D3GB (assurez-vous que le package est disponible)
if (!requireNamespace("D3GB", quietly = TRUE)) {
  install.packages("D3GB")
}
library(D3GB)

# Créer un répertoire temporaire pour stocker les fichiers
temp_dir <- tempdir()

# Télécharger les fichiers nécessaires (FASTA et GFF)
fasta_file <- file.path(temp_dir, "genomic.fna.gz")
gff_file <- file.path(temp_dir, "genomic.gff.gz")

download.file(
  url = "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/297/395/GCF_000297395.2_ASM29739v2/GCF_000297395.2_ASM29739v2_genomic.fna.gz",
  destfile = fasta_file
)

download.file(
  url = "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/297/395/GCF_000297395.2_ASM29739v2/GCF_000297395.2_ASM29739v2_genomic.gff.gz",
  destfile = gff_file
)

# Créer une assembly à partir du fichier FASTA
assembly <- getAssemblyFromFasta(fasta_file)

# Générer un navigateur génomique interactif avec l'assembly
genome_browser <- genomebrowser(assembly)

# Ajouter la séquence génomique au navigateur
genome_addSequence(genome_browser, fasta_file)

# Ajouter les annotations (GFF) au navigateur
genome_addGFF(genome_browser, gff_file)

# Sauvegarder le navigateur pour un affichage local
output_dir <- file.path(temp_dir, "GenomeBrowser")
genome_createLocalMode(genome_browser, dir = output_dir)

# Ouvrir le fichier HTML généré dans le navigateur par défaut
html_file <- file.path(output_dir, "index.html")
browseURL(html_file)
