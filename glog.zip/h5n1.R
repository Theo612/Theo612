
# Installer et charger le package D3GB (assurez-vous que le package est disponible)
if (!requireNamespace("D3GB", quietly = TRUE)) {
  install.packages("D3GB")
}
library(D3GB)

# Définir le chemin vers votre dataset téléchargé
dataset_dir <- "ncbi_dataset/data/GCF_000865725.1/"

# Vérifiez que vous avez les fichiers FASTA et GFF
fasta_file <- file.path(dataset_dir, "GCF_000865725.1_ViralMultiSegProj15521_genomic.fna")
gff_file <- file.path(dataset_dir, "genomic.gff")

# Vérifiez si les fichiers existent
if (!file.exists(fasta_file) || !file.exists(gff_file)) {
  stop("Les fichiers FASTA ou GFF sont introuvables dans le dataset. Vérifiez les chemins.")
}

# Créer une assembly à partir du fichier FASTA
assembly <- getAssemblyFromFasta(fasta_file)

# Générer un navigateur génomique interactif avec l'assembly
genome_browser <- genomebrowser(assembly)

# Ajouter la séquence génomique au navigateur
genome_addSequence(genome_browser, fasta_file)

# Ajouter les annotations (GFF) au navigateur
genome_addGFF(genome_browser, gff_file)

# Sauvegarder le navigateur pour un affichage local
output_dir <- file.path(getwd(), "GenomeBrowser_H5N1")
genome_createLocalMode(genome_browser, dir = output_dir)

# Ouvrir le fichier HTML généré dans le navigateur par défaut
html_file <- file.path(output_dir, "index.html")
browseURL(html_file)

