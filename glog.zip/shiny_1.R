library(shiny)

# Définir le chemin vers votre répertoire contenant index.html
html_dir <- file.path(getwd(), "GenomeBrowser_H5N1")
html_file <- file.path(html_dir, "index.html")

# Définir un alias pour le répertoire contenant les ressources
shiny::addResourcePath("genomeBrowser", html_dir)

# Créer une application Shiny
ui <- fluidPage(
  titlePanel("Affichage du Génome H5N1"),
  
  # Inclure le fichier HTML dans un iframe avec un chemin relatif
  tags$iframe(src = "genomeBrowser/index.html", width = "100%", height = "800px")
)

server <- function(input, output, session) {}

# Lancer l'application Shiny
shinyApp(ui, server)
